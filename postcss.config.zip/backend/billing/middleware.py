from django.conf import settings
from rest_framework import exceptions
from django.utils.deprecation import MiddlewareMixin
import uuid
from typing import Callable, Optional

from billing.credits import CreditEnforcer
from billing.rate_limit import RateLimiter

import logging

logger = logging.getLogger(__name__)

class BillingMiddleware(MiddlewareMixin):
    """
    Middleware to enforce rate limits and credit deductions for specific API endpoints.
    """
    RATE_LIMIT_CONFIG = {
        "/api/v1/ai/chat": {"requests_per_minute": 60},
        "/api/v1/agent/run": {"requests_per_minute": 60}, # ADDED for Agent Playground
        "/api/v1/analytics/insights": {"requests_per_minute": 10},
        "/api/v1/channels/event": {"requests_per_minute": 120},
        "/api/v1/copilot/insights/chat": {"requests_per_minute": 10},
        "/api/v1/integrations/ingest": {"requests_per_minute": 30},
        "/api/v1/external/agent/run": {"requests_per_minute": 30},
        "/api/v1/external/events": {"requests_per_minute": 100},
        "/api/v1/external/data/ingest": {"requests_per_minute": 20},
    }

    def __init__(self, get_response: Callable):
        self.get_response = get_response
        self.rate_limiters: Dict[str, RateLimiter] = {}
        for endpoint, config in self.RATE_LIMIT_CONFIG.items():
            self.rate_limiters[endpoint] = RateLimiter(requests_per_minute=config["requests_per_minute"])

    def process_view(self, request, view_func, view_args, view_kwargs):
        if not hasattr(request, 'user_id') or not hasattr(request, 'workspace_id'):
            return None

        workspace_id = request.workspace_id
        user_jwt = request.auth
        path = request.path_info
        method = request.method

        rate_limiter_key: Optional[str] = None
        for endpoint_prefix in self.RATE_LIMIT_CONFIG.keys():
            if path.startswith(endpoint_prefix):
                rate_limiter_key = endpoint_prefix
                break

        if rate_limiter_key:
            rate_limiter = self.rate_limiters[rate_limiter_key]
            try:
                rate_limiter.check_and_apply_rate_limit(workspace_id, rate_limiter_key)
            except exceptions.Throttled as e:
                logger.warning(
                    "Rate limit exceeded",
                    extra={"workspace_id": workspace_id, "path": path},
                )
                raise e

        # Credit deduction for AI calls
        if method == 'POST' and (path.startswith("/api/v1/ai/chat") or path.startswith("/api/v1/agent/run")):
            if not user_jwt:
                raise exceptions.AuthenticationFailed("JWT missing for credit enforcement.")
            
            # agent_id is optional for check_and_deduct_ai_credit.
            # In middleware, we cannot reliably extract agent_id from request body
            # without consuming the stream, which would interfere with DRF views.
            # So, we pass None and rely on check_and_deduct_ai_credit to handle it.
            # The actual agent_id will be used for detailed logging in runtime.py.
            agent_id = None 

            try:
                credit_enforcer = CreditEnforcer(user_jwt)
                credit_enforcer.check_and_deduct_ai_credit(
                    workspace_id=workspace_id, 
                    agent_id=agent_id, 
                    channel="playground" if path.startswith("/api/v1/agent/run") else None, 
                )
                logger.info(
                    "AI credit deducted",
                    extra={"workspace_id": workspace_id, "path": path, "agent_id": str(agent_id)},
                )
            except exceptions.PaymentRequired as e:
                logger.warning(
                    "Insufficient credits for AI operation",
                    extra={"workspace_id": workspace_id, "path": path, "agent_id": str(agent_id)},
                )
                raise e
            except Exception as e:
                logger.error(
                    "Error during credit enforcement",
                    extra={"workspace_id": workspace_id, "path": path, "error": str(e)},
                    exc_info=True,
                )
                raise exceptions.APIException("An unexpected error occurred during credit processing.")

        return None
