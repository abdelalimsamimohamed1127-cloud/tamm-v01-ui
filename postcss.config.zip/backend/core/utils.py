# Utility functions for the core app
# No specific utilities required for Stage 1.
