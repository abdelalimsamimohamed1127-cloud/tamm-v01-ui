import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { serve } from "https://deno.land/std@0.224.0/http/server.ts";
import OpenAI from "https://deno.land/x/openai@v4.57.0/mod.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { corsHeaders } from "../_shared/cors.ts";

type RunAgentRequest = {
  message?: string;
  session_id?: string;
  agent_id?: string;
  mode?: string; // ADDED
};

const encoder = new TextEncoder();

function roughTokens(text: string | null | undefined) {
  return Math.max(1, Math.ceil((text?.length ?? 0) / 4));
}

function formatContext(
  rows: { content?: string; similarity?: number; title?: string }[],
) {
  if (!rows.length) return "Context:\n(none)";
  const lines = rows.map((row, idx) => {
    const content = row.content?.trim() ?? "";
    const sim = typeof row.similarity === "number" ? row.similarity.toFixed(3) : "0.000";
    const title = row.title ? ` (source: ${row.title})` : "";
    return `[${idx + 1}] (${sim}) ${content}${title}`;
  });
  return `Context:\n${lines.join("\n")}`;
}

// Helper to generate a simple UUID for internal tracing if X-Request-ID is missing
function generateUuid(): string {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// Structured logger
function logEvent(event: string, details: Record<string, any>, requestId: string, level: 'info' | 'warn' | 'error' = 'info') {
  const logObject = {
    timestamp: new Date().toISOString(),
    level,
    event,
    request_id: requestId,
    ...details,
  };
  console.log(JSON.stringify(logObject));
}

serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const requestId = req.headers.get("X-Request-ID") || generateUuid(); // Extract or generate request_id

  logEvent("request_start", { method: req.method, url: req.url }, requestId);

  try {
    const openaiKey = Deno.env.get("OPENAI_API_KEY");
    const supabaseUrl = Deno.env.get("SUPABASE_URL");
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
    if (!openaiKey || !supabaseUrl || !serviceKey) {
      const errorMessage = "Missing environment variables";
      logEvent("runtime_error", { message: errorMessage, type: "env_config" }, requestId, 'error');
      return new Response(JSON.stringify({ error: errorMessage }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { message, session_id, agent_id, mode } = await req.json() as RunAgentRequest; // ADDED mode here
    if (!message || !session_id || !agent_id) {
      const errorMessage = "message, session_id, and agent_id are required";
      logEvent("runtime_error", { message: errorMessage, type: "missing_params", request_body: { message, session_id, agent_id } }, requestId, 'error');
      return new Response(JSON.stringify({ error: errorMessage }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, serviceKey);
    const openai = new OpenAI({ apiKey: openaiKey });

    // --- Fetch Agent Details and Config ---
    const currentMode = mode || "live"; // Default mode to 'live' if not provided

    const { data: agentData, error: agentFetchError } = await supabase
      .from("agents")
      .select("id, workspace_id, draft_version_id, published_version_id, config") // Select version IDs and legacy config
      .eq("id", agent_id)
      .maybeSingle();

    if (agentFetchError || !agentData) {
      const errorMessage = `Agent not found: ${agentFetchError?.message || 'unknown'}`;
      logEvent("runtime_error", { message: errorMessage, type: "agent_lookup_fail", agent_id, db_error: agentFetchError?.message }, requestId, 'error');
      return new Response(JSON.stringify({ error: errorMessage }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const workspaceId = agentData.workspace_id; // Use agentData

    // --- Resolve Agent Configuration (Versioning Logic) ---
    let agentConfig: Record<string, any> = {};
    const configFieldPrefix = currentMode === "test" ? "draft" : "published";
    const versionIdToUse = agentData[f"{configFieldPrefix}_version_id"]; // e.g., 'draft_version_id' or 'published_version_id'

    if (versionIdToUse) {
        const { data: versionData, error: versionError } = await supabase
            .from("agent_versions")
            .select("config_jsonb")
            .eq("id", versionIdToUse)
            .single();
        if (versionError) {
            logEvent("runtime_error", { message: `Error fetching versioned config: ${versionError.message}`, type: "version_fetch_fail", agent_id, version_id: versionIdToUse }, requestId, 'warn');
        } else if (versionData) {
            agentConfig = versionData.config_jsonb || {};
        }
    }

    // Fallback to legacy 'config' field if no versioned config found or retrieved
    if (Object.keys(agentConfig).length === 0) {
        agentConfig = agentData.config || {};
        if (Object.keys(agentConfig).length > 0) {
            logEvent("runtime_warning", { message: `Using legacy config for agent ${agent_id}, mode ${currentMode}. No versioned config found.`, agent_id, mode: currentMode }, requestId, 'warn');
        } else {
             logEvent("runtime_error", { message: `No configuration found for agent ${agent_id}, mode ${currentMode}.`, agent_id, mode: currentMode }, requestId, 'error');
             return new Response(JSON.stringify({ error: "Agent configuration not found." }), {
                status: 500,
                headers: { ...corsHeaders, "Content-Type": "application/json" },
             });
        }
    }
    
    // Extract required settings from agentConfig
    const systemPrompt = agentConfig.system_prompt || "You are a helpful AI assistant.";
    const historySize = agentConfig.history_size || 5; // Default to 5 if not in config

    const { data: session, error: sessionError } = await supabase
      .from("chat_sessions")
      .select("id, workspace_id, agent_id")
      .eq("id", session_id)
      .maybeSingle();
    if (sessionError || !session) {
      const errorMessage = `Session not found: ${sessionError?.message || 'unknown'}`;
      logEvent("runtime_error", { message: errorMessage, type: "session_lookup_fail", session_id, db_error: sessionError?.message, workspace_id: workspaceId, agent_id }, requestId, 'error');
      return new Response(JSON.stringify({ error: errorMessage }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    if (session.agent_id !== agent.id || session.workspace_id !== agent.workspace_id) {
      const errorMessage = "Session/agent mismatch";
      logEvent("runtime_error", { message: errorMessage, type: "session_agent_mismatch", session_id, agent_id, workspace_id: workspaceId }, requestId, 'error');
      return new Response(JSON.stringify({ error: errorMessage }), {
        status: 403,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const workspaceId = agent.workspace_id;

    const { data: balanceData, error: balanceError } = await supabase.rpc(
      "get_wallet_balance",
      { workspace_id: workspaceId },
    );
    if (balanceError) {
      const errorMessage = `Unable to check balance: ${balanceError.message}`;
      logEvent("runtime_error", { message: errorMessage, type: "balance_check_fail", workspace_id: workspaceId, agent_id, db_error: balanceError.message }, requestId, 'error');
      return new Response(JSON.stringify({ error: errorMessage }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
    const balance = typeof balanceData === "number" ? balanceData : balanceData?.balance ?? 0;
    if (balance <= 0) {
      const errorMessage = "Insufficient credits";
      logEvent("runtime_error", { message: errorMessage, type: "insufficient_credits", workspace_id: workspaceId, agent_id, balance }, requestId, 'warn');
      return new Response(JSON.stringify({ error: errorMessage }), {
        status: 402,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    logEvent("agent_invocation_params", { message_length: message.length, session_id, agent_id, workspaceId, mode: currentMode }, requestId);

    // --- Fetch Conversation History ---
    const { data: historyRows, error: historyError } = await supabase
      .from("agent_chat_messages") // Use agent_chat_messages table
      .select("role, content") // Only select role and content
      .eq("session_id", session_id)
      .order("created_at", { ascending: true }) // Order by created_at ascending
      .limit(historySize); // Limit by historySize from agent config

    const history = (historyError ? [] : (historyRows ?? [])).map((row) => ({
      role: row.role as "user" | "assistant", // Only user or assistant for history
      content: row.content ?? "",
    }));

    // --- Context Generation (existing logic) ---
    // This part remains as it was, but is now before constructing the final messages array.
    const embeddingResponse = await openai.embeddings.create({
      model: "text-embedding-3-small",
      input: message,
    });
    const embedding = embeddingResponse.data?.[0]?.embedding;

    const { data: matchRows, error: matchError } = await supabase.rpc("match_site_pages", {
      query_embedding: embedding,
      match_count: 5,
      workspace_id: workspaceId,
    });

    const filteredMatches = (matchError ? [] : (matchRows ?? []))
      .filter((row: any) => Number(row.similarity ?? 0) > 0.75)
      .slice(0, 5);
    const context = formatContext(filteredMatches);

    const fullSystemPrompt = `${systemPrompt}\n\nUse this context: ${context}. If unsure, say "I don't know".`;


    const messages = [
      {
        role: "system",
        content: fullSystemPrompt,
      },
      ...history,
      { role: "user", content: message },
    ] as { role: "user" | "assistant" | "system"; content: string }[];

    const completion = await openai.chat.completions.create({
      model: "gpt-4o-mini",
      stream: true,
      messages,
    });

    const inputTokens = roughTokens(
      messages.map((m) => `${m.role}: ${m.content ?? ""}`).join("\n"),
    );
    let outputTokens = 0;
    let fullText = "";

    const stream = new ReadableStream({
      async start(controller) {
        try {
          for await (const chunk of completion) {
            const delta = chunk.choices?.[0]?.delta?.content ?? "";
            if (delta) {
              fullText += delta;
              outputTokens += roughTokens(delta);
              controller.enqueue(encoder.encode(delta));
            }
          }
          controller.close();

          logEvent("model_response_received", { input_tokens: inputTokens, output_tokens: outputTokens, full_text_length: fullText.length, session_id, agent_id, workspace_id }, requestId);

          const { error: messageError } = await supabase.from("chat_messages").insert([
            {
              session_id,
              role: "user",
              content: message,
              token_count: roughTokens(message),
            },
            {
              session_id,
              role: "assistant",
              content: fullText,
              token_count: outputTokens,
            },
          ]);
          if (messageError) {
            logEvent("runtime_error", { message: `Failed to save chat messages: ${messageError.message}`, type: "db_write_fail", session_id, agent_id, workspace_id, db_error: messageError.message }, requestId, 'error');
            throw messageError;
          }

          outputTokens = Math.max(outputTokens, roughTokens(fullText));

          const costUsd = (inputTokens * 0.00000015) + (outputTokens * 0.0000006);

          await supabase.from("usage_events").insert({
            workspace_id: workspaceId,
            agent_id,
            event_type: "model_inference",
            model: "gpt-4o-mini",
            input_tokens: inputTokens,
            output_tokens: outputTokens,
            cost_usd: costUsd,
          }).catch((e) => {
            logEvent("runtime_error", { message: `Failed to save usage event: ${e.message}`, type: "db_write_fail", workspace_id, agent_id, db_error: e.message }, requestId, 'error');
          });

          await supabase.rpc("deduct_credits", {
            workspace_id: workspaceId,
            amount: costUsd,
          }).catch((e) => {
            logEvent("runtime_error", { message: `Failed to deduct credits: ${e.message}`, type: "db_write_fail", workspace_id, db_error: e.message }, requestId, 'error');
          });

          const runClassification = async () => {
            try {
              const result = await openai.chat.completions.create({
                model: "gpt-4o-mini",
                stream: false,
                messages: [
                  {
                    role: "system",
                    content:
                      "Analyze the last user message and the assistant reply.\nReturn ONLY valid JSON in this format:\n\n{\n  sentiment: 'positive' | 'neutral' | 'negative',\n  topic: string (max 3 words),\n  urgency: 'low' | 'medium' | 'high'\n}",
                  },
                  { role: "user", content: message },
                  { role: "assistant", content: fullText },
                ],
              });

              const raw = result.choices?.[0]?.message?.content ?? "";
              if (!raw) return;

              const parsed = JSON.parse(raw) as {
                sentiment?: string;
                topic?: string;
                urgency?: string;
              };

              const payload: Record<string, string | undefined> = {
                sentiment: parsed.sentiment,
                topic: parsed.topic,
                urgency: parsed.urgency,
              };

              await supabase
                .from("chat_sessions")
                .update(payload)
                .eq("id", session_id)
                .throwOnError();
            } catch (e: any) {
              logEvent("runtime_error", { message: `Classification failed: ${e.message}`, type: "classification_fail", session_id, db_error: e.message }, requestId, 'error');
            }
          };

          const runtime = (globalThis as any)?.EdgeRuntime;
          if (runtime?.waitUntil) {
            runtime.waitUntil(runClassification());
          } else {
            runClassification().catch((e) => {
              logEvent("runtime_error", { message: `Classification failed (no waitUntil): ${e.message}`, type: "classification_fail", session_id, error_details: e.message }, requestId, 'error');
            });
          }
        } catch (err: any) { // Catch errors within the ReadableStream start method
          logEvent("runtime_error", { message: `Stream processing error: ${err.message}`, type: "stream_error", session_id, agent_id, workspace_id, error_details: err.message }, requestId, 'error');
          controller.error(err);
        }
      },
    });

    logEvent("response_stream_start", { session_id, agent_id, workspace_id }, requestId);
    return new Response(stream, {
      headers: {
        ...corsHeaders,
        "Content-Type": "text/plain; charset=utf-8",
        "Transfer-Encoding": "chunked",
      },
    });
  } catch (e: any) {
    const errorMessage = String((e as any)?.message ?? e);
    logEvent("runtime_error", { message: `Top-level handler error: ${errorMessage}`, type: "unhandled_exception", error_details: errorMessage }, requestId, 'error');
    return new Response(JSON.stringify({ error: errorMessage }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
