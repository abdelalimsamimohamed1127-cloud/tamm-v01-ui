// chat runtime
