export { supabase, isSupabaseConfigured } from '@/integrations/supabase/client'
