// This file is no longer needed and will be removed in a future refactor.
// The new create/join workspace experience is implemented in src/components/settings-dialogs/CreateWorkspaceDialog.tsx
export {};