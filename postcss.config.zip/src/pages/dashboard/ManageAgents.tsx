// This file is no longer needed and will be removed in a future refactor.
// The new manage agents experience is implemented in src/components/settings-dialogs/ManageAgentsDialog.tsx
export {};