import { Navigate } from 'react-router-dom';
import Landing from './Landing';

// Index page renders the Landing page
export default function Index() {
  return <Landing />;
}
