// This file is no longer needed and will be removed in a future refactor.
// The new account settings experience is implemented in src/components/settings-dialogs/AccountDialog.tsx
export {};