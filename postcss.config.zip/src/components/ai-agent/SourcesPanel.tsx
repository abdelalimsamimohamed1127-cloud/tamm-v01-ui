// sources panel
